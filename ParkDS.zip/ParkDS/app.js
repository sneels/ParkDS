"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
console.log('Hello world');
const ParkDS_1 = require("./lib/ParkDS");
const Config_1 = require("./lib/Config/Config");
const Account_1 = require("./lib/Config/Account");
const Domain_1 = require("./lib/Config/Domain");
const DataSource_1 = require("./lib/Config/DataSource");
const Entity_1 = require("./lib/Logger/Entity");
const Log_1 = require("./lib/Logger/Log");
const LogType_1 = require("./lib/Logger/LogType");
const parkds = new ParkDS_1.default();
const config = Config_1.default.Instance;
const domain = new Domain_1.default();
const account = new Account_1.default();
const admin = new Account_1.default();
const datasource = new DataSource_1.default();
class logobserver {
    Update(log) {
        console.log(`${log.Type}: ${log.TimeStamp} - ${log.Entity.Name}@${log.Entity.Domain}: ${log.Content}`);
    }
}
var lo = new logobserver();
parkds.Logger.AddObserver(lo);
var entity = new Entity_1.default();
entity.Name = "Test Log";
entity.Domain = "Jozef";
Log_1.default.Register(entity, LogType_1.LogType.STATUS, "TEST");
//# sourceMappingURL=app.js.map