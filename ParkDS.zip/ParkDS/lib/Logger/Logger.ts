﻿import Log from "./Log";
import ILogObserver from "./ILogObserver";

export default class Logger {
    private static _instance: Logger;
    private _loggers: ILogObserver[];
    private constructor() {
        this._loggers = [];
    }

    public static get Instance(): Logger {
        if (this._instance == null) {
            this._instance = new Logger();
        }

        return this._instance;
    }

    public Log(log: Log): void {
        for (var i in this._loggers) {
            this._loggers[i].Update(log);
        }
    }

    public AddObserver(logger) {
        this._loggers.push(logger);
    }

    public RemoveObserver(logger) {
        try {
            for (var i in this._loggers) {
                if (this._loggers[i] == logger) {
                    this._loggers.splice(parseInt(i), 1);
                    break;
                }
            }
        } catch {
            // DO NOTHING
        }
    }
}