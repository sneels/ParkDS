﻿export enum LogType {
    ERROR = "ERROR",
    TRAFFIC = "TRAFFIC",
    STATUS = "STATUS"
}