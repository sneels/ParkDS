﻿export default class Entity {
    private _name: string;
    private _domain: string;

    public constructor() {

    }

    public get Name(): string {
        return this._name;
    }

    public set Name(value: string) {
        this._name = value;
    }

    public get Domain(): string {
        return this._domain;
    }

    public set Domain(value: string) {
        this._domain = value;
    }
}