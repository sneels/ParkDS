﻿import Log from "./Log";

export default interface ILogObserver {
    Update(log: Log):void;
}