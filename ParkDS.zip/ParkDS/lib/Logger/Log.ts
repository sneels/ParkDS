﻿import { LogType } from "./LogType";
import Entity from "./Entity";
import Logger from "./Logger";

export default class Log {
    private _type: LogType;
    private _entity: Entity;
    private _time: Date;
    private _content: any;

    private constructor(entity: Entity, type: LogType, content: any) {
        this._type = type;
        this._entity = entity;
        this._content = content;
        this._time = new Date();
    }

    public static Register(entity: Entity, type: LogType, content: any) {
        let log = new Log(entity, type, content);
        log.sendToLogger(log);
    }

    private sendToLogger(log: Log) {
        let logger = Logger.Instance;
        logger.Log(log);
    }

    public get Type(): LogType {
        return this._type;
    }

    public get TimeStamp(): Date {
        return this._time;
    }

    public get Content(): any {
        return this._content;
    }

    public get Entity(): Entity {
        return this._entity;
    }
}