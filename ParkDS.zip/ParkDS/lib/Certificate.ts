﻿export default class Certificate {
    _cert: Buffer;
    _key: Buffer;

    constructor(cert?: Buffer, key?: Buffer) {
        this._cert = cert;
        this._key = key;
    }

    public get Cert(): Buffer {
        return this._cert;
    }

    public set Cert(value: Buffer) {
        this._cert = value;
    }

    public get Key(): Buffer {
        return this._key;
    }

    public set Key(value: Buffer) {
        this._key = value;
    }
}