﻿import ServerClient from "./ServerClient";
import WebSocket = require("ws");

export default class ServerClientList {
    private static _instance: ServerClientList;
    private _list: ServerClient[];

    private constructor() {
        this._list = [];
    }

    public static get Instance(): ServerClientList {
        if (this._instance == null) {
            this._instance = new ServerClientList();
        }

        return this._instance;
    }

    /**
     * Add a WebSocket Server Client to the list.
     * @param {ServerClient} client The Client.
     */
    public Add(client: ServerClient): void {
        this._list.push(client);
    }

    public GetClient(ws:WebSocket) {
        for (var i in this._list) {
            if (this._list[i].WebSocket == ws) {
                return this._list[i];
            }
        }
    }

    public GetClientByName(name: string) {
        for (var i in this._list) {
            if (this._list[i].Token.User == name) {
                return this._list[i];
            }
        }
    }

    public RemoveClient(ws: WebSocket) {
        for (var i in this._list) {
            if (this._list[i].WebSocket == ws) {
                this._list.splice(parseInt(i), 1);
            }
        }
    }

    /**
     * Remove the Server Client by searching by name
     * @param {string} name The name
     * @public
     */
    public RemoveClientByName(name) {
        for (var i in this._list) {
            if (this._list[i].Token.User == name) {
                this._list.splice(parseInt(i), 1);
            }
        }
    }

    public get List(): ServerClient[] {
        return this._list;
    }
}