﻿import WebSocket = require("ws");
import url = require("url");
import Token from "../Token/Token";
import PackagesContainer from "../../../DataSource/Package/PackagesContainer";
import Entity from "../../../Logger/Entity";
import Config from "../../../Config/Config";
import Log from "../../../Logger/Log";
import { LogType } from "../../../Logger/LogType";
import Queue from "../../../DataSource/Queue";
import Router from "../../../DataSource/Router";
import Server from "../Server";
import ServerClientList from "./ServerClientList";

export default class ServerClient {
    private _ws: WebSocket;
    private _token: Token;
    private _entity: Entity;
    private _config: Config;

    public constructor(ws?:WebSocket) {
        this._entity = new Entity();
        this._entity.Name = "ParkDS WebSocket Server";
        this._entity.Domain = this._config.Settings.Name;

        if (ws != null) {
            this._ws = ws;
        }
    }

    /**
     * Send a Packages Container to the client
     * @param {PackagesContainer} pkgcontainer the Packages Container
     */
    Send(pkgcontainer: PackagesContainer) {
        let obj: string = this.createJSON(pkgcontainer);
        this._ws.Send(obj);
    }

    /**
     * Event Handler: OnMessage
     * @param {string} message
     */
    public OnMessage(message) {
        let queue: Queue = Queue.Instance;
        let server = Server.Instance;

        try {
            Log.Register(this._entity, LogType.TRAFFIC, "Message received!");

            let obj: Object = JSON.parse(message);
            var pkgcontainer = this.createPackagesContainer(obj);

            if (obj["reroute"] === undefined) {

                if (pkgcontainer.ReturnToSender) {
                    queue.ResolvePackages(pkgcontainer);
                } else {
                    let router = new Router();
                    router.Route(pkgcontainer, 1);
                }
            } else {
                server.SendToClient(pkgcontainer);
            }
        } catch (e) {
            this.OnError(e);
        }
    }


    /**
     * Event Handler: OnClose
     * @param {any} code
     * @param {any} reason
     */
    public OnClose(code, reason) {
        if (reason == "") {
            reason = "Connection Terminated Abnormally";
        }
        // Log Error
        var err = new Error(reason)
        err["code"] = code;
        Log.Register(this._entity, LogType.ERROR, err);
        var entity = new Entity();

        // Log status change
        entity.Name = this._token.User;
        entity.Domain = this._token.Path;
        Log.Register(entity, LogType.STATUS, -1);

        let cl = ServerClientList.Instance;
        cl.RemoveClientByName(this._token.User);
    }

    /**
     * Event Handler: OnError
     * @param {Error} e
     */
    public OnError(e: Error) {
        Log.Register(this._entity, LogType.ERROR, e);
    }

    public get WebSocket(): WebSocket {
        return this._ws;
    }

    public set WebSocket(ws: WebSocket) {
        this._ws = ws;
    }

    public get Token(): Token {
        return this._token;
    }

    public set Token(value: Token) {
        this._token = value;
    }

    /**
     * Create a Packages Container from a JSON string
     * @param {string} json The JSON string
     * @returns {PackagesContainer}
     */
    private createPackagesContainer(obj: object): PackagesContainer {
        try {
            let pkgcontainer = new PackagesContainer(obj["packet"]);

            return pkgcontainer;
        } catch (e) {
            Log.Register(this._entity, LogType.ERROR, "Invalid or missing Packet in Websocket message");
        }
    }

    /**
     * Create a JSON string from a PackagesContainer
     * @param {PackagesContainer} pkgcontainer The Packages Container
     * @returns {string}
     */
    private createJSON(pkgcontainer: PackagesContainer): string {
        var obj = new Object();
        obj["token"] = this._token;
        obj["packet"] = pkgcontainer.ToObject();
        return JSON.stringify(obj);
    }
}