﻿import TokenList from "./Token/TokenList";
import WebSocket = require("ws");
import https = require("https");
import PackagesContainer from "../../DataSource/Package/PackagesContainer";
import Package from "../../DataSource/Package/Package";
import Log from "../../Logger/Log";
import Entity from "../../Logger/Entity";
import Config from "../../Config/Config";
import { LogType } from "../../Logger/LogType";
import { IncomingMessage, ServerResponse } from "http";
import url = require("url");
import qs = require('querystring');
import ServerClient from "./Client/ServerClient";
import ServerClientList from "./Client/ServerClientList";

export default class Server {
    private static _instance: Server;
    private _tokenList: TokenList;
    private _wss: WebSocket.Server;
    private _https: https.Server;

    private _config: Config;
    private _entity: Entity;
    private _clientList: ServerClientList;

    // Server Config Properties
    private _port: number;
    private _status: number;
    
    private constructor() {
        WebSocket.
        this._tokenList = TokenList.Instance;
        this._status = 0;
        this._entity = new Entity();
        this._config = Config.Instance;
        this._clientList = ServerClientList.Instance;

        this._entity.Name = "ParkDS WebSocket Server";
        this._entity.Domain = this._config.Settings.Name;
    }

    public static get Instance(): Server {
        if (this._instance == null) {
            this._instance = new Server();
        }

        return this._instance;
    }

    /**
     * 
     * Initialize the WebSocket Server by providing the Listening Port + Certification + Key
     * @param {number} port The Listening Port
     * @param {Buffer} certification The Certification
     * @param {Buffer} key The Key
     */
    public Init(port: number, certification:Buffer, key:Buffer) {
        this._port = port;
        this._https = https.createServer({
            cert: certification,
            key: key
        }, (this.httpsListener).bind(this));

        this._https.on('listening', (this.OnListening).bind(this));
        var server = this._https;
        this._wss = new WebSocket.Server({
            server,
            verifyClient: (this.verifyClient).bind(this)
        });
    }


    /**
     * Start the server
     * @public
     */
    Start() {
        this._wss.on('connection', (this.OnConnection.bind(this)));
        this._https.listen(this._port);

    }

    /**
     * Stop the server
     * */
    Stop() {
        this._wss.close(function (e) {

        });
        this._https.close(function (e) {

        });
    }

    private verifyClient(info, done) {
        let query = url.parse(info.req.url, true).query;
        try {
            var token = this._tokenList.GetTokenByName(query.authtoken.toString());
            if (typeof (token) != "undefined") {
                var ip = info.req.socket._handle._parentWrap.remoteAddress;
                if (token.IP == ip) {
                    info.req.token = token;
                    done(true);
                } else {
                    this.OnError("Unauthorized Connection Attempt");
                    done(false, 401);
                }
            } else {
                this.OnError("Unauthorized Connection Attempt");
                done(false, 401);
            }
        }
        catch (e) {
            this.OnError("Unauthorized Connection Attempt");
            done(false, 401);
        }
    }

    private OnListening() {
        this._status = 1;

        Log.Register(this._entity, LogType.STATUS, 1)
        Log.Register(this._entity, LogType.TRAFFIC, `WebSocket Servr is now running and listening to port ${this._port}`);
    }

    private httpsListener(req: IncomingMessage, res: ServerResponse) {
        switch (req.url) {
            case "/auth":
                if (req.method == 'POST') {
                    var body = '';
                    req.on('data', function (data) {
                        body += data;
                    });

                    req.on('end', function () {

                        var post = JSON.parse(qs.unescape(body));
                        var md5 = require('md5');
                        var cfg = new (require('../../Config/Config'));
                        var domain;
                        for (var key in cfg.Domains) {
                            if (cfg.Domains[key].Name == post.user) {
                                domain = cfg.Domains[key];
                            }
                        }

                        if (typeof (domain) !== "undefined" && domain.hasOwnProperty("Name")) {
                            var hashstr = domain.Name + ":" + cfg.Settings.Password + "@" + domain.Path;
                            var hash = md5(hashstr);
                            if (hash == post.pass) {

                                var TokenList = new (require('./Token/TokenList'));

                                var Token = require('./Token/Token');
                                var ip;

                                if (req.headers['x-forwarded-for']) {
                                    ip = req.headers['x-forwarded-for'].toString().split(",")[0];
                                } else if (req.connection && req.connection.remoteAddress) {
                                    ip = req.connection.remoteAddress;
                                }

                                var token = new Token(domain.Name, domain.Path, ip);
                                TokenList.Add(token);
                                res.writeHead(200, { 'Content-Type': 'application/json', 'authtoken': token.Token });
                                res.end("Authentication for Websockets");
                            } else {
                                res.statusCode = 401;
                                res.end();
                            }
                        } else {
                            res.statusCode = 401;
                            res.end();
                        }
                    });
                }
                else {
                    res.statusCode = 404;
                    res.end();
                }
                break;

            case "acp/login":

                break;

            default:
                res.writeHead(404)
                break;
        }

        Log.Register(this._entity, LogType.TRAFFIC, `URL Accessed: ${req.url}`);
    }

    public SendToClient(pkgcontainer: PackagesContainer) {
        try {
            if (pkgcontainer.ReturnToSender) {
                this._clientList.GetClientByName(pkgcontainer.Sender).Send(pkgcontainer);
            }
            else {
                this._clientList.GetClientByName(pkgcontainer.Recipient).Send(pkgcontainer);
            }
        } catch (e) {
            Log.Register(this._entity, LogType.ERROR, e);
        }
    }

    /**
    * On Connection Event Handler
    * @param {WebSocket} ws
    * @param {any} request
    */
    OnConnection(ws, request) {
        var client = new ServerClient();
        //console.
        var token = request.token;

        Log.Register(this._entity, LogType.TRAFFIC, "Client Connected.");

        try {
            if (token == this._tokenList.GetTokenByName(token.Token)) {
                client.Token = token;
                this._tokenList.Remove(token.Token);

                // Client Event Handlers
                ws.on('message', (client.OnMessage).bind(client));
                ws.on('close', (client.OnClose).bind(client));

                client.WebSocket = ws;
                this._clientList.Add(client);
            }
        }
        catch (e) {
            Log.Register(this._entity, LogType.ERROR, e);
        }

    }

    OnError(e) {
        console.log(e);
    }
}