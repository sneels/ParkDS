﻿import Token from "./Token";

export default class TokenList {
    private static _instance: TokenList;
    private _tokens: Token[];

    private constructor() {
        this._tokens = [];
    }

    public static get Instance(): TokenList {
        if (this._instance == null) {
            this._instance = new TokenList();
        }

        return this._instance;
    }

    public Add(token: Token): void {
        this._tokens.push(token);
        var self = this;

        setTimeout(function () {
            
        }, 10000);
    }

    public GetToken(token: Token) {
        for (var i in this._tokens) {
            if (this._tokens[i].Token == token.Token) {
                return this._tokens[i];
            }
        }

        throw new Error("Token does not exist!");
    }


    public GetTokenByName(token: string) {
        for (var i in this._tokens) {
            if (this._tokens[i].Token == token) {
                return this._tokens[i];
            }
        }

        throw new Error("Token does not exist!");
    }


    public get Tokens(): Token[] {
        return this._tokens;
    }

    public Remove(token: Token) {
        for (var i in this._tokens) {
            if (this._tokens[i].Token == token.Token) {
                this._tokens.splice(parseInt(i), 1);
                break;
            }
        }
    }
}