﻿import UUID = require("uuid/v1");

export default class Token {
    private _user: string;
    private _path: string;
    private _ip: string;
    private _token: string;

    public constructor(user: string, path: string, ip: string) {
        this._user = user;
        this._path = path;
        this._ip = ip;
        this._token = UUID();
    }

    public get User(): string {
        return this._user;
    }

    public set User(value: string) {
        this._user = value;
    }

    public get Path(): string {
        return this._path;
    }

    public set Path(value: string) {
        this._path = value;
    }

    public get IP(): string {
        return this._ip;
    }

    public set IP(value: string) {
        this._ip = value;
    }

    public get Token(): string {
        return this._token;
    }

    public set Token(value: string) {
        this._token = value;
    }
}