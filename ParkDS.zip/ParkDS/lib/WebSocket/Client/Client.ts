﻿import WebSocket = require('ws');
import md5 = require('md5');
import https = require('https');

import Token from '../Server/Token/Token';
import Config from '../../Config/Config';
import PackagesContainer from '../../DataSource/Package/PackagesContainer';
import Entity from '../../Logger/Entity';
import { LogType } from '../../Logger/LogType';
import Log from '../../Logger/Log';
import { Server, ServerResponse, IncomingMessage } from 'http';
import Queue from '../../DataSource/Queue';
import Router from '../../DataSource/Router';

export default class {
    private _ws: WebSocket;
    private _token: Token;
    private _retries: number;
    private _status: number;
    private _config: Config;
    private _authstring: string;
    private _data: string;
    private _options: object;
    private _server: object;
    private _entity: Entity;
    private _name: string;
    private _path: string;

    public constructor(domain, authurl) {
        this._name = this._config.Settings.Name;
        this._path = this._config.Settings.Path;
        this._entity = new Entity();
        this._entity.Name = `ParkDS WebSocket Client ${this._name}@${this._path}`;
        this._entity.Domain = this._config.Settings.Name;

        this._retries = 0;
        this._status = 0;
        this._server = {
            Name: domain,
            Address: this._config.Domains[domain].Path,
            Port: this._config.Domains[domain].Port,
            Path: authurl
        };
    }

    public get Name(): string {
        return this._name;
    }

    public get Domain(): string {
        return this._server['Name'];
    }

    private CreateAuthString() {
        var string = `${this._config.Settings.Account.User}:${this._config.Settings.Account.Password}@${this._path}`;
        this._authstring = md5(string);
    }

    private CreateData() {
        this._data = JSON.stringify({
            user: this._config.Settings.Account.User,
            pass: this._authstring
        });
    }

    public CreateOptions(requestCert, rejectUnauthorized) {
        var data = this._data;
        this._options = {
            hostname: this._server['Address'],
            port: this._server['Port'],
            path: this._server['Path'],
            method: "POST",
            headers: {
                'Content-Type': 'application/json',
                'Content-Length': data.length
            },
            requestCert: requestCert,
            rejectUnauthorized: rejectUnauthorized
        }
    }

    private requestToken(res: IncomingMessage) {
        var self = this;
        if (res.statusCode == 200) {
            self._token = new Token(res.headers.authtoken['User'], res.headers.authtoken['Path'], res.headers.authtoken['IP']);
            self._token.Token = res.headers.authtoken['Token'];

            Log.Register(self._entity, LogType.TRAFFIC, `Token Received: ${res.headers.authtoken}`);

            try {
                var ws = new WebSocket(`wss://${self._server['Address']}:${self._server['Port']}?authtoken=${res.headers.authtoken}`, {
                    rejectUnauthorized: false
                });

                var Clients = null;
                ws.on("error", function (e) {
                    Log.Register(self._entity, LogType.TRAFFIC, "Connection Failed");
                    Log.Register(self._entity, LogType.ERROR, e);
                });

                ws.on("open", function () {
                    self._status = 2;
                    // if (self.Retries > 0) {
                    Clients.Add(self);
                    // }
                    self._retries = 0;
                    Clients.Update();
                });

                ws.on("upgrade", function (e) {
                    Log.Register(self._entity, LogType.STATUS, "Connected to Server");
                });

                ws.on("message", function (message) {
                    Log.Register(self._entity, LogType.STATUS, `Message Received.`);

                    var dsp = self.createPackagesContainer(message);
                    if (dsp.ReturnToSender) {
                        var queue = Queue.Instance;
                        queue.ResolvePackages(dsp);
                    } else {
                        var dsr = new Router();
                        dsr.Route(dsp, 2);
                    }
                });
                ws.on("close", function (errc, errm) {
                    if (self._status == 2) {
                        self._status = 1;
                        Log.Register(self._entity, LogType.TRAFFIC, `Connection terminated: Code ${errc}: ${errm}.`);

                        Clients.Remove(self);
                        Clients.Update();
                        self.Reconnect();
                    }
                });
                self._ws = ws;
                res.on('data', function (d) {
                });
            } catch (e) {
                if (e.code == 'ECONNREFUSED') {
                    self.Reconnect();
                }
            }
        } else if (res.statusCode == 404) {
            self._status = 0;
            self.Reconnect();
            Log.Register(self._entity, LogType.TRAFFIC, `${self._name}@${self._path}\x1b[31m]: Request failed.`);
        } else {
            self._status = 0;
            self.Reconnect();

            Log.Register(self._entity, LogType.TRAFFIC, `${self._name}@${self._path}\x1b[31m]: Request failed.`);
        }

        Log.Register(self._entity, LogType.STATUS, self._status);
    }

    public Connect() {
        if (this._status >= 0 && this._status <= 1) {
            var self = this;

            Log.Register(this._entity, LogType.TRAFFIC, " Requesting Auth Token...");

            try {
                var req = https.request(self._options, (this.requestToken).bind(this)); 
                req.write(this._data);
                req.end();
            } catch {
                self._status = 0;
                self.Reconnect();
            }
        }
    }

    Disconnect() {
        this._status = 0;
        this._ws.close();
    }

    /**
     * Attempt to Reconnect to the server (max tries: 10)
     * @private
     * */
    Reconnect() {

        //if (this._retries < 10) {
        var e = 0;
        if (this._retries == 0) {
            e = 1;
        } else if (this._retries == 9) {
            e = 600;
        } else {
            for (var i = 0; i <= this._retries; i++) {
                e += Math.pow(2, i);
            }
        }

        this._retries++;
        var s = e * 1000;

        var self = this;
        setTimeout(function () {
            self.Connect();
        }, s);
        /* } else {
             this._status = -1;
             ParkDS.WebSocket.Client.Clients.Update();
         }//*/
    }

    /**
     * 
     * @param {PackagesContainer} dspc
     */
    Send(dspc, reroute) {
        if (this._status == 2) {
            var obj = this.createJSON(dspc);
            if (reroute) {
                obj = JSON.parse(obj);
                if (dspc.IsResolved) {
                    obj['reroute'] = dspc.Sender;
                } else {
                    obj['reroute'] = dspc.Recipient;
                }
                obj = JSON.stringify(obj);
            }
            this._ws.send(obj);
        } else {
            dspc.DeferredState.Reject();
        }
    }

    /**
     * Create a Packages Container from a JSON string
     * @param {string} json The JSON string
     * @returns {PackagesContainer}
     */
    private createPackagesContainer(obj: object): PackagesContainer {
        try {
            let pkgcontainer = new PackagesContainer(obj["packet"]);

            return pkgcontainer;
        } catch (e) {
            
            Log.Register(this._entity, LogType.ERROR, "Invalid or missing Packet in Websocket message");
        }
    }

    /**
     * Create a JSON string from a PackagesContainer
     * @param {PackagesContainer} pkgcontainer The Packages Container
     * @returns {string}
     */
    private createJSON(pkgcontainer: PackagesContainer): string {
        var obj = new Object();
        obj["token"] = this._token;
        obj["packet"] = pkgcontainer.ToObject();
        return JSON.stringify(obj);
    }
}