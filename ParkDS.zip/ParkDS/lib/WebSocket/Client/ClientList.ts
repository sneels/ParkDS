﻿import Client from "./Client";

export default class ClientList {
    private static _instance: ClientList;
    private _list: Client[];

    private constructor() {
        this._list = [];
    }

    public static get Instance(): ClientList {
        if (this._instance == null) {
            this._instance = new ClientList();
        }

        return this._instance;
    }

    /**
     * Adds a WebSocket Client to the list
     * @param {Client} client the WebSocket Client
     */
    public Add(client: Client) {
        this._list.push(client);
    }


    /**
     * Remove a client from the list
     * @param {Client} client
     */
    public Remove(client) {
        try {
            client.Close();
        }
        catch (e) {
            // DO NOTHING
        }

        for (var i in this._list) {
            if (this._list[i] == client) {
                this._list.slice(parseInt(i), 1);
            }
        }
    }

    public get List(): Client[] {
        return this._list;
    }

    public GetClientByDomainName(name: string) {


        for (var i in this._list) {
            if (this._list[i].Domain == name) {
                return this._list[i];
            }
        }
    }
}