﻿import Domain from "./Domain";
import IList from "../GenericInterfaces/IList";

export default class DomainList implements IList {
    private _domains: Domain[];

    public constructor() {
        this._domains = [];
    }

    public get List(): Domain[] {
        return this._domains;
    }

    public Add(domain: Domain): void {
        this._domains.push(domain);
    }

    public Remove(domain: Domain): void {
        var i:number = null;
        this._domains.forEach(function (dom: Domain, index: number) {
            if (dom == domain) {
                i = index;
            }
        });
        this._domains.splice(i, 1);
    }

    public GetByName(name: string): Domain {
        let domain: Domain;
        for (var i in this._domains) {
            if (this._domains[i].Name == name) {
                domain = this._domains[i];
                break;
            }
        }

        if (domain == null) {
            throw new Error(`Data Source '${name}' does not exist`);
        }
        return domain;
    }
}