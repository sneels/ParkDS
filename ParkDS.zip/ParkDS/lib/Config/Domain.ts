﻿import Account from "./Account";

export default class Domain {
    private _name: string;
    private _path: string;
    private _port: number;
    private _isCloud: boolean;
    private _account: Account;
    public constructor() {

    }

    public get Name(): string {
        return this._name;
    }

    public set Name(value: string) {
        this._name = value;
    }

    public get Path(): string {
        return this._path;
    }

    public set Path(value: string) {
        this._path = value;
    }

    public get Port(): number {
        return this._port;
    }

    public set Port(value: number) {
        this._port = value;
    }

    public get IsCloud(): boolean {
        return this._isCloud;
    }

    public set IsCloud(value: boolean) {
        this._isCloud = value;
    }

    public get Account(): Account {
        return this._account;
    }
}