﻿import DataSource from "./DataSource";
import IList from "../GenericInterfaces/IList";

export default class DataSourceList implements IList {
    private _datasources: DataSource[];

    public constructor() {
        this._datasources = [];
    }

    public get List(): DataSource[] {
        return this._datasources;
    }

    public Add(datasource: DataSource): void {
        this._datasources.push(datasource);
    }

    public Remove(datasource: DataSource): void {
        var i: number = null;
        this._datasources.forEach(function (ds: DataSource, index: number) {
            if (ds == datasource) {
                i = index;
            }
        });
        this._datasources.splice(i, 1);
    }

    public GetByName(name: string): DataSource {
        let datasource: DataSource;
        for (var i in this._datasources) {
            if (this._datasources[i].Name == name) {
                datasource = this._datasources[i];
                break;
            }
        }

        if (datasource !== null) {
            return datasource;
        }
        else {
            throw new Error(`Data Source '${name}' does not exist`);
        }
    }
}