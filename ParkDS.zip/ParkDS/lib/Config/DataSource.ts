﻿import Domain from "./Domain";
import Account from "./Account";

export default class DataSource {
    private _name: string;
    private _type: string;
    private _domain: Domain;
    private _path: string;
    private _account: Account;
    private _dbname: string;
    private _options: object;

    public constructor(name?: string, type?: string, path?: string, domain?: Domain, account?:Account, datasource?: string, options?: object) {
        this._name = name;
        this._type = type;
        this._path = path;
        this._dbname = datasource;

        this._options = new Object();
        if (options != null) {
            this._options = options
        }

        this._domain = new Domain();
        if (domain != null) {
            this._domain = domain;
        }

        this._account = new Account();
        if (account != null) {
            this._account = account;
        }
    }

    public get Name(): string {
        return this._name;
    }

    public set Name(value: string) {
        this._name = value;
    }

    public get Type(): string {
        return this._type;
    }

    public set Type(value: string) {
        this._type = value;
    }

    public get Domain(): Domain {
        return this._domain;
    }

    public set Domain(value: Domain) {
        this._domain = value;
    }

    public get Path(): string {
        return this._path;
    }

    public set Path(value: string) {
        this._path = value;
    }

    public get User(): string {
        return this._account.User;
    }

    public set User(value: string) {
        this._account.User = value;
    }

    public get Password(): string {
        return this._account.Password;
    }

    public set Password(value: string) {
        this._account.Password = value;
    }

    public get Datasource(): string {
        return this._dbname;
    }

    public set Datasource(value: string) {
        this._dbname = value;
    }

    public get Options(): object {
        return this._options;
    }

    public set Options(value: object) {
        this._options = value;
    }
}