﻿import Settings from "./Settings";
import DomainList from "./DomainList";
import DataSourceList from "./DataSourceList";
import Certificate from "../Certificate";
export default class Config {
    private static _instance: Config;
    private _settings: Settings;
    private _domains: DomainList;
    private _datasources: DataSourceList;
    private _certificate: Certificate;

    private constructor() {
        this._settings = new Settings();
        this._domains = new DomainList();
        this._datasources = new DataSourceList();
        this._certificate = new Certificate();
    }

    public static get Instance(): Config {
        if (this._instance == null) {
            this._instance = new Config();
        }

        return this._instance;
    }

    public get Domains(): DomainList {
        return this._domains;
    }

    public get DataSources(): DataSourceList {
        return this._datasources;
    }

    public get Settings(): Settings {
        return this._settings;
    }

    public get Certificate(): Certificate {
        return this._certificate;
    }

    public set Certificate(value: Certificate) {
        this._certificate = value;
    }
}