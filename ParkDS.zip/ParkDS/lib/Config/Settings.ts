﻿import Account from "./Account";
import Domain from "./Domain";
export default class Settings {
    private _domain: Domain;
    private _admin: Account;
    private _account: Account
    public constructor(domain?: Domain, account?: Account, admin?: Account) {
        if (domain == null) {
            this._domain = new Domain();
        } else {
            this._domain = domain;
        }

        if (account == null) {
            this._account = new Account();
        } else {
            this._account = account;
        }

        if (admin == null) {
            this._admin = new Account();
        } else {
            this._admin = admin;
        }
    }

    public Set(domain: Domain, account: Account, admin: Account):void {
        this._domain = domain;
        this._admin = admin;
        this._account = account;
    }

    public get Name(): string {
        return this._domain.Name;
    }

    public set Name(value:string) {
        this._domain.Name = value;
    }

    public get Path(): string {
        return this._domain.Path;
    }

    public set Path(value: string) {
        this._domain.Path = value;
    }

    public get Port(): number {
        return this._domain.Port;
    }

    public set Port(value: number) {
        this._domain.Port = value;
    }

    public get IsCloud(): boolean {
        return this._domain.IsCloud;
    }

    public set IsCloud(value: boolean) {
        this._domain.IsCloud = value;
    }
    
    public get Account(): Account {
        return this._account;
    }

    public set Account(value: Account) {
        this._account = value;
    }

    public get Admin(): Account {
        return this._admin;
    }

    public set Admin(value:Account) {
        this._admin = value;
    }
}