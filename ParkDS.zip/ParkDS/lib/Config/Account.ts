﻿export default class Account {
    private _user: string;
    private _pass: string;

    public constructor() {

    }

    public get User():string {
        return this._user;
    }

    public set User(value:string) {
        this._user = value;
    }

    public get Password():string {
        return this._pass;
    }

    public set Password(value:string) {
        this._pass = value;
    }
}