﻿import Logger from "./Logger/Logger";
import Config from "./Config/Config";
import Manager from "./DataSource/Manager";
import Package from "./DataSource/Package/Package";
import Log from "./Logger/Log";
import Entity from "./Logger/Entity";
import { LogType } from "./Logger/LogType";
import PackagesContainer from "./DataSource/Package/PackagesContainer";
import ConnectorList from "./DataSource/Connector/ConnectorList";
import Server from "./WebSocket/Server/Server";
import ServerClientList from "./WebSocket/Server/Client/ServerClientList";
import Client from "./WebSocket/Client/Client";
import ClientList from "./WebSocket/Client/ClientList";
import DataSource from "./Config/DataSource";

export default class ParkDS {
    private _logger: Logger;
    private _config: Config;
    private _manager: Manager;
    private _package: Package;
    private _log: Log;
    private _connectors: ConnectorList;

    constructor() {
        this._logger = Logger.Instance;
        this._config = Config.Instance;
        this._connectors = ConnectorList.Instance;
    }

    public get Logger(): Logger {
        return this._logger;
    }
    
    public Log(entity: Entity, type: LogType, content: any): void {
        Log.Register(entity, type, content);
    }

    public get Config(): Config {
        return this._config;
    }

    public get Manager(): Manager {
        return new Manager();
    }

    public get Package(): Package {
        return new Package();
    }

    public get PackagesContainer(): PackagesContainer {
        return new PackagesContainer();
    }

    public get Connectors(): ConnectorList {
        return this._connectors;
    }

    public get DataSource(): DataSource {
        return new DataSource();
    }

    public Start(): void {
        var wss = Server.Instance;
        wss.Init(this.Config.Settings.Port, this.Config.Certificate.Cert, this.Config.Certificate.Key);
        wss.Start();

        var clients = ServerClientList.Instance;
        for (var domain in this.Config.Domains.List) {
            if ((domain != this.Config.Settings.Name) && this.Config.Domains[domain].IsCloud) {

                var wsClient = new Client(domain, "/auth");
                ClientList.Instance.Add(wsClient);
                wsClient.Connect();
            }
        }
    }

    public Stop(): void {
        var wss = Server.Instance;
        wss.Stop();

        var clients = ServerClientList.Instance;
        for (var domain in this.Config.Domains.List) {
            if ((domain != this.Config.Settings.Name) && this.Config.Domains[domain].IsCloud) {

                var wsClient = new Client(domain, "/auth");
                ClientList.Instance.Remove(wsClient);
                wsClient.Disconnect();
            }
        }
    }

}