﻿export default interface IList {
    Add(item:any): void;
    Remove(item: any): void;
    GetByName(name: string): any;
}