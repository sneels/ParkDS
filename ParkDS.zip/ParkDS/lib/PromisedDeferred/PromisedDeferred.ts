﻿import Deferred = require("deferred");
export default class PromisedDeferred {
    private _state: Deferred;

    constructor() {
        this._state = new Deferred();
    }

    Promise() {
        let def = this._state;
        return new Promise(function (resolve, reject) {
            var req = function () {
                return def.promise.then(function (value) {
                    resolve(value);
                }, function (value) {
                    reject(value);
                });
            }

            req();
        });
    }

    Resolve(value: any): void {
        this._state.resolve(value);
    }

    Reject(value: any): void {
        this._state.reject(value);
    }
}