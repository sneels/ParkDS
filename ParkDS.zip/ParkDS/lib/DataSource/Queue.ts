﻿import PackagesContainer from "./Package/PackagesContainer";
import Log from "../Logger/Log";
import Entity from "../Logger/Entity";
import Config from "../Config/Config";
import { LogType } from "../Logger/LogType";
import Package from "./Package/Package";

export default class Queue {
    private static _instance: Queue;
    private _queue: PackagesContainer[];
    private _entity: Entity;
    private _config: Config;

    private constructor() {
        this._queue = [];
        this._entity = new Entity();
        this._config = Config.Instance;

        this._entity.Name = "ParkDS Queue";
        this._entity.Domain = this._config.Settings.Name;
    }

    public static get Instance():Queue {
        if (this._instance == null) {
            this._instance = new Queue;
        }
        return this._instance;
    }

    public Add(pkgcontainer: PackagesContainer) {
        this._queue.push(pkgcontainer);

        Log.Register(this._entity, LogType.TRAFFIC, `Container Added (Queue Size: ${this._queue.length})`);

        let p = pkgcontainer.Promise();
        let self = this;
        //let q = this._queue;
        setTimeout(function () {
            self.remove(pkgcontainer);
        }, 15000);
        p.then((this.remove).bind(this));
        /*p.then(function (value:PackagesContainer) {
            for (var i in q) {
                if (q[i].id == value.id) {
                    q.splice(i, 1);
                }
            }
        });*/

        return p;
    }

    public ResolvePackage(pkg:Package) {
        let qid: number = this.getId(pkg.ContainerId);
        if (typeof (this._queue[qid]) != "undefined" && typeof this._queue[qid].id !== 'undefined' && this._queue[qid].id == pkg.ContainerId) {
            for (var i in this._queue[qid].Packages) {
                if (this._queue[qid].Packages[i].id == pkg.id) {
                    this._queue[qid].Packages[i].Result = pkg.Result;
                    this._queue[qid].Packages[i].State = pkg.State;
                    this._queue[qid].Packages[i].ReturnToSender = pkg.ReturnToSender;
                    this._queue[qid].Packages[i].IsResolved = true;
                    if (pkg.State == 1) {
                        this._queue[qid].Packages[i].Resolve();
                    }
                    else {
                        this._queue[qid].Packages[i].Reject(pkg.Result.Error);
                    }

                }
            }
        }
    }

    public ResolvePackages(pkgcontainer:PackagesContainer) {
        let qid: number = this.getId(pkgcontainer.id);
        if (typeof (this._queue[qid]) != "undefined" && typeof this._queue[qid].id !== 'undefined' && this._queue[qid].id == pkgcontainer.id) {
            for (var i in this._queue[qid].Packages) {
                for (var j in pkgcontainer.Packages) {
                    if (this._queue[qid].Packages[i].id == pkgcontainer.Packages[j].id) {
                        this._queue[qid].Packages[i].Result = pkgcontainer.Packages[j].Result;
                        this._queue[qid].Packages[i].State = pkgcontainer.Packages[j].State;
                        this._queue[qid].Packages[i].ReturnToSender = pkgcontainer.Packages[j].ReturnToSender;
                        if (pkgcontainer.Packages[j].State == 1) {
                            this._queue[qid].Packages[i].Resolve();
                        } else {
                            if (pkgcontainer.Packages[j].State == -1) {
                                this._queue[qid].Packages[i].Reject(pkgcontainer.Packages[j].Result.Error)
                            }
                        }
                    }
                }
            }
        }
    }

    private getId(pkgcontainerId):number {
        for (var i in this._queue) {
            if (this._queue[i].id == pkgcontainerId) {
                return parseInt(i);
            }
        }
    }

    private remove(pkgcontainer) {
        for (var i in this._queue) {
            if (this._queue[i].id == pkgcontainer.id) {
                this._queue.splice(parseInt(i), 1);
            }
        }
    }

    private reject(pkgcontainer) {
        var i = this.getId(pkgcontainer.id);
        if (typeof (this._queue[i]) != "undefined" && typeof this._queue[i].id !== 'undefined' && this._queue[i].id == pkgcontainer.id) {
            this._queue[i].Reject(new Error("Processing Timed Out"));

            Log.Register(this._entity, LogType.ERROR, `Packages processing timed out`);
        }
    }
}