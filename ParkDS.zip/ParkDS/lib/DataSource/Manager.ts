﻿import PackagesContainer from "./Package/PackagesContainer";
import Config from "../Config/Config";
import Package from "./Package/Package";
import Log from "../Logger/Log";
import Entity from "../Logger/Entity";
import { LogType } from "../Logger/LogType";
import Router from "./Router";

export default class Manager {
    private _pkgcontainer: PackagesContainer;
    private _config: Config;
    private _entity: Entity;
    public constructor() {
        this._pkgcontainer = new PackagesContainer();
        this._config = Config.Instance;
        this._entity = new Entity();

        this._pkgcontainer.Sender = this._config.Settings.Name;

        this._entity.Domain = this._config.Settings.Name;
        this._entity.Name = "ParkDS Manager";
    }

    /**
     * Adds a Package to the Packages Container (Requires Manager.Execute() to be processed).
     * @param {Package} pkg
     */
    public Add(pkg: Package) {
        this._pkgcontainer.Add(pkg);

        // LOGGING TRAFFIC:
        Log.Register(this._entity, LogType.TRAFFIC, `Package added to Container, Total Packages: ${this._pkgcontainer.Packages.length}`);
    }

    public AddAsync(pkg: Package) {
        const pc = new PackagesContainer();
        pc.Sender = this._config.Settings.Name;

        // LOGGING TRAFFIC:
        Log.Register(this._entity, LogType.TRAFFIC, `Package Routed. Total Packages: ${pc.Packages.length}`);

        // todo: add routing
    }

    public Execute() {
        var router = new Router();

        // LOGGING: TRAFFIC
        Log.Register(this._entity, LogType.TRAFFIC, `Container Routed. Total Packages: ${this._pkgcontainer.Packages.length}`);

        return router.Route(this._pkgcontainer, 0);
    }
}