﻿import GenericPackage from "./GenericPackage";
import Package from "./Package";
import PromisedDeferred from "../../PromisedDeferred/PromisedDeferred";

export default class PackagesContainer extends GenericPackage {
    private _sender: string;
    private _recipient: string;
    private _packages: Package[];
    private _packageStates: any[];
    private _Result: Error;

    public constructor(obj?:object) {
        super();
        this._packages = [];
        this._packageStates = [];

        if (obj != null) {
            this.id = obj['id'];
            this.State = obj['State'];
            this.ReturnToSender = obj['ReturnToSender'];
            this.Sender = obj['Sender'];
            this.Recipient = obj['Recipient'];
            for (var i in obj['Packages']) {
                this.Add(new Package(obj['Packages'][i]));
            }
        }
    }

    public Add(pkg: Package): void {
        pkg.ContainerId = this.id;
        this._packageStates.push(pkg.Promise());
    }

    public Promise() {
        let self = this;
        Promise.all(this._packageStates).then(function () {
                self.Resolve();
        }).catch(function (error: Error) {
            self.Reject(error);
        });
        return this._promisedState.Promise();
    }

    public Resolve():void {
        this._promisedState.Resolve(this);
    }

    public Reject(error: Error): void {
        this._isResolved = true;
        if (this._state != -1) {
            for (var i in this._packages) {
                if (!this._packages[i].IsResolved) {

                    this._packages[i].Reject(error);
                }
            }
        }

        this._state = -1;
        this._Result = error;
        this._promisedState.Reject(this);
    }

    public get Sender(): string {
        return this._sender;
    }

    public set Sender(value: string) {
        this._sender = value;
    }

    public get Recipient(): string {
        return this._recipient;
    }

    public set Recipient(value: string) {
        this._recipient = value;
    }

    public get Packages(): Package[] {
        return this._packages;
    }

    /**
     * Returns the class in a generic Object format
     * @returns {Object}
     * */
    ToObject() {
        var obj = new Object();
        obj['id'] = this.id;
        obj['State'] = this.State;
        obj['ReturnToSender'] = this.ReturnToSender;
        obj['Sender'] = this.Sender;
        obj['Recipient'] = this.Recipient;
        obj['Packages'] = [];

        for (var i in this.Packages) {
            obj['Packages'].push(this.Packages[i].ToObject());
        }

        return obj;
    }
}