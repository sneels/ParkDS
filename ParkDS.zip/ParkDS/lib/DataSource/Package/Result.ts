﻿export default class Result {
    private _error: Error;
    private _data: object;

    constructor() {
        this._error = null;
        this._data = null;
    }

    public get Error(): Error {
        return this._error;
    }

    public set Error(value: Error) {
        this._error = value;
    }

    public get Data(): object {
        return this._data;
    }

    public set Data(value: object) {
        this._data = value;
    }
}