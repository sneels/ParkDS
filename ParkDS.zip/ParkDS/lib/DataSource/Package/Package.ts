﻿import GenericPackage from "./GenericPackage";
import Result from "./Result";
import Query from "./Query";

import ErrorToJSON = require("error-to-json");

export default class Package extends GenericPackage {
    private _query: Query;
    private _datasoure: string;
    private _containerID: string;
    private _result: Result;
    private _name: string;

    public constructor(obj?:object) {
        super();
        if (obj != null) {
            this.id = obj['id'];
            this.State = obj['State'];
            this.IsResolved = obj['IsResolved'];
            this.ReturnToSender = obj['ReturnToSender'];
            this.Name = obj['Name'];
            this.DataSource = obj['DataSource'];
            this.ContainerId = obj['ContainerId'];
            this._query = obj['Query'];
            var result = new Result();
            result.Data = obj['Result']['Data'];
            if (obj['Result']['Error'] != null) {
                var json = JSON.stringify(obj["Result"]["Error"])
                result.Error = ErrorToJSON.parse(json);
            }
            this._result = result;
        }
        
    }

    public get Name(): string {
        return this._name;
    }

    public set Name(value: string) {
        this._name = value;
    }

    public get DataSource(): string {
        return this._datasoure;
    }

    public set DataSource(value: string) {
        this._datasoure = value;
    }

    public get ContainerId(): string {
        return this._containerID;
    }

    public set ContainerId(value: string) {
        this._containerID = value;
    }

    public get Query(): Query {
        return this._query;
    }

    public get Result(): Result {
        return this._result;
    }

    public set Result(value: Result) {
        this._result = value;
    }

    public Promise() {
        return this._promisedState.Promise();
    }

    public Resolve() {
        this.State = 1;
        this._promisedState.Resolve(this);
    }

    public Reject(error: any) {
        this.State = -1;
        this._result.Error = error;
        this._promisedState.Reject(this)
    }

    public ToObject(): object {
        let obj = new Object();

        obj['id'] = this.id;
        obj['State'] = this.State;
        obj['IsResolved'] = this.IsResolved;
        obj['ReturnToSender'] = this.ReturnToSender;
        obj['Name'] = this.Name;
        obj['DataSource'] = this.DataSource;
        obj['ContainerId'] = this.ContainerId;
        obj['Query'] = this.Query;

        var result = new Object();
        result['Error'] = null;
        result['Data'] = this._result.Data;

        if (this._result.Error != null) {
            result['Error'] = JSON.parse(ErrorToJSON(this.Result.Error))
        }

        obj['Result'] = result;
        
        return obj;
    }
}