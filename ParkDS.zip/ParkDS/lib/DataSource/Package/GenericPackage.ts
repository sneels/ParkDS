﻿import UUID =  require("uuid/v1");
import PromisedDeferred from "../../PromisedDeferred/PromisedDeferred";
export default class GenericPackage {
    protected _id: string;
    protected _promisedState:PromisedDeferred;
    protected _state: number;
    protected _returnToSender: boolean;
    protected _isResolved: boolean;

    public constructor() {
        this._id = UUID();
        this._promisedState = new PromisedDeferred();
        
        this._state = 0;
        this._returnToSender = false;
        this._isResolved = false;
    }

    /**
     * @returns Creates a promise to return itself when completed.
     * */
    public Promise() {
        return this._promisedState.Promise();
    }

    /**
     * Resolve it's state.
     * */
    public Resolve() {
        this._state = 1;
        this.Resolve();
    }

    /**
     * Reject the Promise (Provide a variable to clarify the reaso.n)
     * @param {any} value
     */
    public Reject(value:any) {
        this._state = -1;
        this._promisedState.Reject(value);
    }

    public get id(): string {
        return this._id;
    }

    public set id(value:string) {
        this._id = value;
    }

    public get State(): number {
        return this._state;
    }

    public set State(value: number) {
        this._state = value;
    }

    public get ReturnToSender(): boolean {
        return this._returnToSender;
    }

    public set ReturnToSender(value: boolean) {
        this._returnToSender = value;
    }

    public get IsResolved(): boolean {
        return this._isResolved;
    }

    public set IsResolved(value: boolean) {
        this._isResolved = value;
    }
}