﻿export default class Query {
    _qstr: string;
    _bindings: object[];

    public constructor() {
        this._qstr = "";
        this._bindings = [];
    }

    public get String():string {
        return this._qstr;
    }

    public set String(value: string) {
        this._qstr = value;
    }

    public get Bindings(): object[] {
        return this._bindings;
    }

    public set Bindings(value: object[]) {
        this._bindings = value;
    }
}