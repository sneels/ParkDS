﻿import Config from "../../Config/Config";
import ConnectorList from "./ConnectorList";
import PromisedDeferred from "../../PromisedDeferred/PromisedDeferred";

export default class ConnectorHandler {
    private _config: Config;

    public constructor() {
        this._config = Config.Instance;
    }

    /**
     * Execute the DataSource Connector
     * @param {Package} dsp A DataSourcePackage to be handled
     * @returns {Promise<Package>}
     * @public
     */
    Execute(dsp) {
        var connectors = ConnectorList.Instance
        var dsc = connectors.List[dsp.Database];
        var def = new PromisedDeferred();
        var result = dsc.Query(dsp.Query);
        result.then(function (value) {
            dsp.Result = value;
            dsp.State = 1;
            dsp.ReturnToSender = true;
            dsp.Resolve();
            def.Resolve(dsp);
        });

        return def.Promise();
    }
}