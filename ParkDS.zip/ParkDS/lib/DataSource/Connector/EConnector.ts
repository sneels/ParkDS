﻿import DataSource from "../../Config/DataSource";
import Query from "../Package/Query";
import PromisedDeferred from "../../PromisedDeferred/PromisedDeferred";

export default class EConnector {
    private _connectionstring: string;
    private _user: string;
    private _pass: string;
    private _path: string;
    private _dbname: string;
    private _options: object;
    private _name: string;
    constructor(datasource: DataSource) {
        this._connectionstring = "";
        this._user = datasource.User;
        this._pass = datasource.Password;
        this._path = datasource.Path;
        this._dbname = datasource.Datasource;
        this._options = datasource.Options;
        this._name = datasource.Name;
    }

    /**
     * Sends a query to the Data Source
     * @param {string} query the query string to retrieve data
     * @returns {Promise} returns a JSON Object
     */
    public Query(query: Query) {
        var def = new PromisedDeferred();
        // Todo connect, query, convert to object, return object
        return def.Promise();
    }

    /**
     * Opens the connection to the Data Source
     * */
    public OpenConnection() {
        // ToDo: write connection
    }

    /**
     * Closes the connection to the Data Source
     * @public
     * */
    public CloseConnection() {

    }

    public get Name(): string {
        return this._name;
    }
}