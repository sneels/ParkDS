﻿import EConnector from "./EConnector";
import Config from "../../Config/Config";

export default class ConnectorList {
    private static _instance: ConnectorList;
    private _list: EConnector[];
    private _config: Config;
    private constructor() {
        this._list = [];
        this._config = Config.Instance;
    }

    public static get Instance(): ConnectorList {
        if (this._instance == null) {
            this._instance = new ConnectorList();
        }
        return this._instance;
    }
    /**
     * Add a Data Source Connector to the list by providing a Name and IConnector
     * @param {EConnector} connector
     */
    public Add(connector) {
        this._list.push(connector);
    }
    /**
     * Add a Data Source Connector to the list by providing a Name and IConnector
     * @param {EConnector} connector
     */
    public Remove(connector) {
        for (var i in this._list) {
            if (this._list[i] == connector) {
                this._list.slice(parseInt(i), 1);
            }
        }
    }

    public get List(): EConnector[] {
        return this._list;
    }

    public ConnectAll() {
        for (var i in this._list) {
            if (this._config.DataSources.GetByName(this._list[i].Name).Domain.Name == this._config.Settings.Name) {
                this._list[i].OpenConnection();
            }
        }
    }

    public DisconnectAll() {
        for (var i in this._list) {
            if (this._config.DataSources.GetByName(this._list[i].Name).Domain.Name == this._config.Settings.Name) {
                this._list[i].CloseConnection();
            }
        }
    }
}