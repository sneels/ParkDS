﻿import Config from "../Config/Config";
import Queue from "./Queue";
import Entity from "../Logger/Entity";
import Log from "../Logger/Log";
import { LogType } from "../Logger/LogType";
import PackagesContainer from "./Package/PackagesContainer";
import DataSource from "../Config/DataSource";
import ServerClientList from "../WebSocket/Server/Client/ServerClientList";
import ClientList from "../WebSocket/Client/ClientList";
import Server from "../WebSocket/Server/Server";

export default class Router {
    private _config: Config;
    private _queue: Queue;
    private _entity: Entity;
    private _fromWebSocket: number;

    public constructor() {
        this._queue = Queue.Instance;
        this._config = Config.Instance;
        this._entity = new Entity();
        this._entity.Name = "ParkDS Router";
        this._entity.Domain = this._config.Settings.Name;

    }

    public Route(pkgcontainer: PackagesContainer, fromWebSocket: number) {
        this._fromWebSocket = fromWebSocket;
        Log.Register(this._entity, LogType.TRAFFIC, "Container Received");

        let queued = this._queue.Add(pkgcontainer);

        let routeObj: object = new Object({
            Local: new PackagesContainer(),
            WebSocket: {
                Client: new Object(),
                Server: new Object()

            }
        });

        routeObj["Local"].id = pkgcontainer.id;

        if (pkgcontainer.Sender == this._config.Settings.Name) {
            for (var i in pkgcontainer.Packages) {
                var ds: DataSource = this._config.DataSources[pkgcontainer.Packages[i].DataSource];

                if (ds.Domain.Name == this._config.Settings.Name) {
                    routeObj["Local"].Packages.push(pkgcontainer[i]);
                } else {
                    if ((this._config.Settings.IsCloud && !this._config.Domains.GetByName(ds.Domain.Name))) {
                        if (typeof (routeObj["WebSocket"]["Server"][ds.Domain.Name]) == "undefined") {
                            routeObj["WebSocket"]["Server"][ds.Domain.Name] = new PackagesContainer();
                            routeObj["WebSocket"]["Server"][ds.Domain.Name].id = pkgcontainer.id;
                            routeObj["WebSocket"]["Server"][ds.Domain.Name].Sender = pkgcontainer.Sender;
                            routeObj["WebSocket"]["Server"][ds.Domain.Name].Recipient = ds.Domain.Name;
                        }

                        routeObj["WebSocket"]["Server"][ds.Domain.Name].Packages.push(pkgcontainer.Packages[i]);
                    } else {
                        if (typeof (routeObj["WebSocket"]["Client"][ds.Domain.Name]) == "undefined") {
                            routeObj["WebSocket"]["Client"][ds.Domain.Name] = new PackagesContainer();
                            routeObj["WebSocket"]["Client"][ds.Domain.Name].id = pkgcontainer.id;
                            routeObj["WebSocket"]["Client"][ds.Domain.Name].Sender = pkgcontainer.Sender;
                            routeObj["WebSocket"]["Client"][ds.Domain.Name].Recipient = ds.Domain.Name;
                        }

                        routeObj["WebSocket"]["Client"][ds.Domain.Name].Packages.push(pkgcontainer.Packages[i]);
                    }
                }
            }
        } else if (pkgcontainer.Recipient == this._config.Settings.Name) {
            this.routeLocally(routeObj["Local"]);
        }

        var size = this.ObjectSize(routeObj["WebSocket"]["Client"]);
        if (size > 0) {
            for (var key in routeObj["WebSocket"]["Client"]) {
                if (routeObj["WebSocket"]["Client"][key].Packages.length > 0) {
                    this.routeThroughWebSocketClient(routeObj["WebSocket"]["Client"][key], routeObj["WebSocket"]["Client"][key].Recipient);
                }
            }
        }

        size = this.ObjectSize(routeObj["WebSocket"]["Server"]);
        if (size > 0) {
            for (var key in routeObj["WebSocket"]["Server"]) {
                if (routeObj["WebSocket"]["Server"][key].Packages.length > 0) {
                    this.routeThroughWebSocketServer(routeObj["WebSocket"]["Server"][key], routeObj["WebSocket"]["Server"][key].Recipient);
                }
            }
        }

        if (fromWebSocket > 0) {
            queued.then((this.routeResolved).bind(this)).catch((this.routeResolved).bind(this));
        }

        return queued;
    }

    private routeResolved(pkgcontainer: PackagesContainer) {
        if (this._fromWebSocket == 1) {
            // Yes? Send it back through the server.
            this.routeThroughWebSocketServer(pkgcontainer, pkgcontainer.Sender);
        } else {
            // No? Send it back through the client.
            this.routeThroughWebSocketClient(pkgcontainer);
        }
    }

    private ObjectSize(obj: object): number {
        var size = 0, key;
        for (key in obj) {
            if (obj.hasOwnProperty(key)) size++;
        }
        return size;
    }

    private routeLocally(pkgcontainer: PackagesContainer): void {
        Log.Register(this._entity, LogType.TRAFFIC, `Routing ${pkgcontainer.Packages.length} Packages Locally.`);
        var q = this._queue
        for (var i in pkgcontainer.Packages) {
            var connectorHandler = new connectorHandler();
            var chResult = connectorHandler.Execute(pkgcontainer.Packages[i]);
            chResult.then(function (value) {
                q.ResolvePackage(value)
            })
        }
    }

    private routeThroughWebSocketServer(pkgcontainer: PackagesContainer, domain: string): void {
        Log.Register(this._entity, LogType.TRAFFIC, `Routing ${pkgcontainer.Packages.length} Packages through the WebSocket Server to ${domain}.`);
        var client;
        var reroute = false;
        if (!this._config.Settings.IsCloud && !this._config.Domains[domain].IsCloud) {
            client = ClientList.Instance.List[0];
            reroute = true;
        } else {
            client = ClientList.Instance.GetClientByDomainName[domain];
        }
        client.Send(pkgcontainer, reroute);
    }

    private routeThroughWebSocketClient(pkgcontainer: PackagesContainer): void {
        Log.Register(this._entity, LogType.TRAFFIC, `Routing ${pkgcontainer.Packages.length} Packages through the WebSocket Server to ${domain}.`);
        var wss = Server.Instance;
        wss.SendToClient(pkgcontainer);
    }
}