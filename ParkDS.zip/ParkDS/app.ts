﻿console.log('Hello world');
import ParkDS from "./lib/ParkDS";
import Config from "./lib/Config/Config";
import Account from "./lib/Config/Account";
import Domain from "./lib/Config/Domain";
import DataSource from "./lib/Config/DataSource";
import GenericPackage from "./lib/DataSource/Package/GenericPackage";
import Entity from "./lib/Logger/Entity";
import Log from "./lib/Logger/Log";
import { LogType } from "./lib/Logger/LogType";
import ILogObserver from "./lib/Logger/ILogObserver";
import ErrorToJSON = require("error-to-json");
import fs = require('fs');
// Required
const parkds = new ParkDS();
var ws = require('ws');

var Config = parkds.Config;
var wsServer;

function CommandLine() {
    const readline = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    })

    readline.question(`input:`, (name) => {
        switch (name) {
            case 'jozef':
                parkds.Config.Settings.Name = "Jozef";
                parkds.Config.Settings.Port = 1337;
                parkds.Config.Settings.IsCloud = false;
                parkds.Connectors.ConnectAll();
                //parkds.Config.StartConnectors();
                parkds.Config.Certificate.Cert = fs.readFileSync('./Certificates/jozef.fracarita.org.pem');
                parkds.Config.Certificate.Key = fs.readFileSync('./Certificates/jozef.fracarita.org.key.pem');
                readline.close();
                CommandLine();
                break;

            case 'azure':
                parkds.Config.Settings.Name = "Azure";
                parkds.Config.Settings.Port = 13370;
                parkds.Config.Settings.IsCloud = true;
                parkds.Connectors.ConnectAll();
                //parkds.Config.StartConnectors();
                parkds.Config.Certificate.Cert = fs.readFileSync('./Certificates/jozef.fracarita.org.pem');
                parkds.Config.Certificate.Key = fs.readFileSync('./Certificates/jozef.fracarita.org.key.pem');
                readline.close();
                CommandLine();
                break;

            case 'test':
                parkds.Config.Settings.Name = "Test";
                parkds.Config.Settings.Port = 8008;
                parkds.Config.Settings.IsCloud = true;
                parkds.Connectors.ConnectAll();
                //parkds.Config.StartConnectors();
                parkds.Config.Certificate.Cert = fs.readFileSync('./Certificates/jozef.fracarita.org.pem');
                parkds.Config.Certificate.Key = fs.readFileSync('./Certificates/jozef.fracarita.org.key.pem');
                readline.close();
                CommandLine();
                break;

            case 'premise':
                parkds.Config.Settings.Name = "Premise";
                parkds.Config.Settings.Port = 8888;
                parkds.Config.Settings.IsCloud = false;
                parkds.Connectors.ConnectAll();
                //parkds.Config.StartConnectors();
                parkds.Config.Certificate.Cert = fs.readFileSync('./Certificates/jozef.fracarita.org.pem');
                parkds.Config.Certificate.Key = fs.readFileSync('./Certificates/jozef.fracarita.org.key.pem');
                readline.close();
                CommandLine();
                break;

            case 'stop':
                parkds.Stop();
                readline.close();
                CommandLine();
                break;

            case 'start':
                parkds.Start();
                readline.close();
                CommandLine();
                break;

            case 'async':
                asyncMsSql();
                readline.close();
                setTimeout(CommandLine, 100);
                break;

            case 'mysql':
                MySQL();
                readline.close();
                setTimeout(CommandLine, 100);
                break;


            case 'mssql':
                MsSql();
                readline.close();
                setTimeout(CommandLine, 100);
                break;

            case 'mysql2':
                MySQL();
                MySQL();
                MySQL();
                MySQL();
                readline.close();
                setTimeout(CommandLine, 100);
                break;

            case 'multi':
                asyncMsSqlMulti();
                readline.close();
                setTimeout(CommandLine, 100);
                break;

            case 'long':
                Test();
                readline.close();
                CommandLine();
                break;


            case 'rem':
                wsServer.RemoveObserver(t);
                readline.close();
                CommandLine();
                break;

            case 'close':
                readline.close();
                break;

            case 'status':
                console.log(wsServer.GetStatus());
                readline.close();
                CommandLine();
                break;

            default:
                readline.close();
                CommandLine();
                break;
        }
    });
}

function connect() {
}

function ParseResult(obj) {
    for (var i in obj.Packages) {
        if (obj.Packages[i].Result.Error) {
            console.table(obj.Packages[i].Result.Error);
        } else {
            console.table(obj.Packages[i].Result.rows)
        }
    }

}

function Package1() {
    var dsp = parkds.Package;

    dsp.DataSource = "MysqlTest";
    dsp.Query.String = "select * from city where CountryCode = ?";
    dsp.Query.Bindings.push(new Object({
        Name: "CountryCode",
        Value: "BEL",
        Type: "nvarchar"
    }));
    return dsp;
}

function Package2() {
    var dsp =  parkds.Package;

    dsp.DataSource = "Orbis";
    dsp.Query.String = "Select distinct Beveiliging.Onderwerp.Id, Onderwerp.Omschrijving as Naam " +
        "from Beveiliging.Onderwerp " +
        "inner join Beveiliging.OnderwerpenPerOnderwerpGroep on Onderwerp.id = OnderwerpenPerOnderwerpGroep.OnderwerpId " +
        "inner join Beveiliging.OnderwerpGroep on OnderwerpGroep.id = OnderwerpenPerOnderwerpGroep.OnderwerpGroepId " +
        "inner join Beveiliging.OnderwerpGroepenPerOnderwerpGroep on OnderwerpGroep.id = OnderwerpGroepenPerOnderwerpGroep.OnderwerpGroepId " +
        "where (Onderwerp.OnderwerpTypeId = 1 " +
        "and OnderwerpGroep.Omschrijving like @leefgroep " +
        "and ISNull(OnderwerpenPerOnderwerpGroep.GeldigTot, cast(getdate() as date)) >= cast(getdate() as date))";
    dsp.Query.Bindings.push(new Object({
        Name: "leefgroep",
        Value: "anemoon",
        Type: "nvarchar"
    }));
    return dsp;
}

function Package3() {
    var dsp = parkds.Package;

    dsp.Database = "MySql2";
    dsp.Query.String = "SELECT * FROM sakila.actor where last_name = ?";
    dsp.Query.Bindings.push(new Object({
        Name: "last_name",
        Value: "cage",
        Type: "nvarchar"
    }));
    return dsp;
}

function MySQL() {
    var dsm = parkds.Manager;
    var result = dsm.AddAsync(Package3());

    result.then(function (value) {
        ParseResult(value);
    });

}

function MsSql() {
    for (var i = 0; i < 1000; i++) {
        var dsm = parkds.Manager;
        var result = dsm.AddAsync(Package2());

        result.then(function (value) {
            for (var i in value.Packages) {
                ParseResult(value);
            }
        });
    }
}

function asyncMsSql() {
    var dsm = parkds.Manager;
    var result = dsm.AddAsync(Package2());

    result.then(function (value) {
        for (var i in value.Packages) {
            ParseResult(value);
        }
    });
}

function asyncMsSqlMulti() {
    var result = [];

    var dsm = parkds.Manager;
    result.push(dsm.AddAsync(Package2()));

    var dsm2 = parkds.Manager;
    result.push(dsm2.AddAsync(Package2()));
    result[0].then(function () {
        console.log("Package 1 is resolved");
    })
    result[1].then(function () {
        console.log("Package 2 is resolved");
    })
    Promise.all(result).then(function (value) {
        for (var i in value) {
            ParseResult(value[i]);
        }
    });
}

function Test() {
    var endres = [];

    var dsm = parkds.Manager;
    dsm.Add(Package1());
    dsm.Add(Package2());
    dsm.Add(Package3());


    var result = dsm.Execute();

    var dsm2 = parkds.Manager;


    var result2 = dsm2.AddAsync(Package2());

    //setTimeout(function () {
    result.then(function (value) {
        endres.push(value);
    });
    var def = new (require('promised-deferred'))();
    var p = def.Promise();

    result2.then(function (value) {
        console.log("resolved");
        def.Resolve(value)
    });
    //setTimeout(function () {
    p.then(function (value) {
        endres.push(value);
    });

    setTimeout(function () {
        for (var i in endres) {
            ParseResult(endres[i]);
        }
    }, 5000);
}

function Load() {
    var cf = fs.readFileSync('./config.json');
    var c = cf.toString();

    var r = JSON.parse(c);

    for (var i in r['DataSources']) {
        var ds = parkds.DataSource;
        ds.Name = r['DataSources'][i]['Name'];
        ds.Type = r['DataSources'][i]['Name'];
        ds.Domain = r['DataSources'][i]['Name'];
        ds.Path = r['DataSources'][i]['Name'];
        ds.Name = r['DataSources'][i]['Name'];
        ds.Name = r['DataSources'][i]['Name'];
        ds.Name = r['DataSources'][i]['Name'];
        ds.Name = r['DataSources'][i]['Name'];
        Config.DataSources.Add(r['DataSources'][i])
    }
    Config.DataSources = r.DataSources;
    Config.Domains = r.Domains;
    Config.Settings = r.Settings;
}


function Init() {
    var Connectors = parkds.Connectors;

    var MySQLConnector = require('./Connectors/Connector.MySql');
    var MySqlTest = new MySQLConnector(parkds.Config.DataSources['MysqlTest']);
    parkds.Connectors.Add(MySqlTest);

    MySQLConnector = require('./Connectors/Connector.MySql');
    var MySql2 = new MySQLConnector(parkds.Config.DataSources['MySql2']);
    parkds.Connectors.Add(MySql2);

    var MsSQLConnector = require('./Connectors/Connector.MsSql');
    var Orbis = new MsSQLConnector(parkds.Config.DataSources['Orbis']);
    parkds.Connectors.Add(Orbis);

    function logger() {
        var Log = function (obj) {
            var time = ('0' + obj.Time.getHours()).slice(-2) + ":" + ('0' + obj.Time.getMinutes()).slice(-2) + ":" + ('0' + obj.Time.getSeconds()).slice(-2) + "." + ('00' + obj.Time.getUTCMilliseconds()).slice(-3);
            console.log(`${time} [${obj.Name}]: ${obj.Message})`)
        }

        return {
            Log: Log
        }
    }

    //ParkDS.DataSource.Queue.AddLogObserver(new logger());
}

// Init
Load();
Init();

CommandLine();
//*/